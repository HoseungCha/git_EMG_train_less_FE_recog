%data�� ref�� ���� transform�ϴ� �Լ�
%
% designed & coded by Dr. Won-Du Chang
% last modified 2017.05.03
function d_trans = transfromData_accRef_usingDTW(data_test, data_ref, option)
    %Normalization
%     data_norm_test = NormalizeFeature_4DTW(data_ref, data_test);
    
    %Add additional Data
    data_reSampled_ref  = Resampling(data_ref, option.nDivision_4Resampling);
    data_reSampled_test = Resampling(data_test, option.nDivision_4Resampling);
    
    %DTW calculation
    [dist, ~, match_pair_ref_test] = fastDPW(data_reSampled_ref, data_reSampled_test, option.max_slope_length, option.speedup_mode);  
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %dist�� ���� ũ�� �̻��̸� transform ���ϴ� �ڵ尡 �ʿ��� ��
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %transformation
    d_trans = transfromData_accDTWresult(data_reSampled_test, data_reSampled_ref, match_pair_ref_test, option.nDivision_4Resampling);
end
